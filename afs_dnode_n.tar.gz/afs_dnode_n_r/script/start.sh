#!/bin/bash

cd .. 

./main

                                    
