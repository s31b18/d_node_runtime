#!/bin/bash

# Define
# Write configuration file
cat <<EOF > conf.json
{ 
	"port"  :    "$host_port",
	"logdir"   :    "./log/",
	"downloaddir"    :      "./download/",
	"mergedir"    :      "./merge/",
	"cachedir" : "./cache/",
	"afsdir"       :     "./afs/",
	"trackers"     :     [
        { "address" :  "http://139.159.244.231:8091" }
	],
	"cache_time" : 1,
	"max_download_thread" : 5,
	"max_download_retry" : 3,
	"max_search_retry" : 3,
	"max_search_thread" : 5
}
EOF

mv conf.json .. 
                                                                         
