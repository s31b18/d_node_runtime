#!/bin/bash
  
# Define 
# runtime_url (depends on installation git in build)
# service_name (depends on service_name in install.sh)
# git_dir_name (depends on source code git repo name)
runtime_url=https://github.com/s31b18/d_node_runtime/raw/master/afs_dnode.tar.gz
service_name=dnode
git_dir_name=afs_dnode_n

tar_postfix=.tar.gz
r_postfix=_r
tar_file_name=$git_dir_name$tar_postfix
decompress_dir=$git_dir_name$r_postfix

current_dir="$PWD"
program_dir=$(dirname $current_dir)
temp_dir=$program_dir/keep

mkdir $temp_dir
cd $temp_dir
wget $runtime_url
tar -xzf $tar_file_name

echo "Use the old configs or reinstall ?(o=old configs/r=reinstall)"
read reinstall

rm -r $program_dir/script
if [ "$reinstall" = "o" ] ; then
        if [ -f "$program_dir/conf.json" ]; then
            mv $program_dir/conf.json $temp_dir
            mv $temp_dir/$decompress_dir/* $program_dir/
            mv $temp_dir/conf.json $program_dir/
        else
            echo "Cannot found the old configs"
            mv $temp_dir/$decompress_dir/* $program_dir/
        fi
else
    mv $temp_dir/$decompress_dir/* $program_dir/
fi

rm -r $temp_dir              
